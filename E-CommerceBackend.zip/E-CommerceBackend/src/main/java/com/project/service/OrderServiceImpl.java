package com.project.service;

import com.project.entity.Order;
import com.project.repository.OrderRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class OrderServiceImpl implements OrderService {

    private final OrderRepository orderRepository;

    public OrderServiceImpl(OrderRepository orderRepository) {
        this.orderRepository = orderRepository;
    }

 // create an order method
    @Override
    public Order createOrder(Order order) {
        // optional: calculate total price if quantity × price needed
        order.setPrice(order.getQuantity() * order.getPrice());
        return orderRepository.save(order);
    }

    // view order by ID
    @Override
    public Order getOrderById(Long id) {
        return orderRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Order not found with id: " + id));
    }

    // view order by custmanem
    @Override
    public List<Order> getOrdersByCustomerName(String customerName) {
        List<Order> orders = orderRepository.findByCustomerName(customerName);
        if (orders.isEmpty()) {
            throw new RuntimeException("No orders available for customer: " + customerName);
        }
        return orders;
    }

    // view all orders
    @Override
    public List<Order> getAllOrders() {
        return orderRepository.findAll();
    }
}
