package com.project.service;

import com.project.entity.Order;
import java.util.List;

public interface OrderService {
	
	
	// create an order method
    Order createOrder(Order order);

    // view order by their ID
    Order getOrderById(Long id);
    
    // view order by customerName
    List<Order> getOrdersByCustomerName(String customerName);

    // VIEW all orders
    List<Order> getAllOrders();
}
