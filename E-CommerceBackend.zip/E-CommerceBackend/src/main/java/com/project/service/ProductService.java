package com.project.service;

import com.project.entity.Product;
import java.util.List;

public interface ProductService {
	// create products method
    Product createProduct(Product product);
    
    // view product by id
    Product getProductById(Long id);
    
    // view all products
    List<Product> getAllProducts();
    
    // update product method
    Product updateProduct(Long id, Product product);
    
    // delete product method
    void deleteProduct(Long id);
}
